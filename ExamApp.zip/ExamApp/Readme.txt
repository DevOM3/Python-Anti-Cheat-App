Notes :-

1] This App is for the purpose of taking Examination only.
2] Don't move any file from this folder or don't try to edit any file
   in this directory or thisi may lead you to the Failure in Examination.
3] Remember to keep the Application open until you finish your Examination.


All the Best